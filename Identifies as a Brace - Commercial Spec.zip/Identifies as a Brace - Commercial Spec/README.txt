print at 100% infill, .1mm layer height

assembly requires a spring, 3mm pin and two screws